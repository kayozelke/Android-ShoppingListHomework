package com.example.shoppinglisthomework

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val CART_NAME_PARAM = "cart name"
private const val CART_POS_PARAM = "cart pos"

/**
 * A simple [Fragment] subclass.
 * Use the [DeleteCartDialogFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DeleteCartDialogFragment : DialogFragment() {
    // TODO: Rename and change types of parameters
    private var cartNameParam: String? = null
    private var cartPosParam: Int? = null
    lateinit var mListener: OnDeleteCartDialogInteractionListener

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            cartNameParam = it.getString(CART_NAME_PARAM)
            cartPosParam = it.getInt(CART_POS_PARAM)
        }
    }


    interface OnDeleteCartDialogInteractionListener{
        fun onDialogPositiveClick(pos:Int?)
        fun onDialogNegativeClick(pos:Int?)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        builder.setMessage("Delete this entry? " + "\"$cartNameParam\"")
        builder.setPositiveButton("Confirm", DialogInterface.OnClickListener{ dialogInterface, i ->
            mListener?.onDialogPositiveClick(cartPosParam)
        } )
        builder.setNegativeButton("Discard", DialogInterface.OnClickListener{ dialogInterface, i ->
            mListener?.onDialogNegativeClick(cartPosParam)
        } )


        return builder.create()
    }

    companion object {
        @JvmStatic
        fun newInstance(name: String, pos: Int, interactionListener: OnDeleteCartDialogInteractionListener) =
            DeleteCartDialogFragment().apply {
                arguments = Bundle().apply {
                    putString(CART_NAME_PARAM, name)
                    putInt(CART_POS_PARAM, pos)
                }
                mListener = interactionListener
            }
    }
}