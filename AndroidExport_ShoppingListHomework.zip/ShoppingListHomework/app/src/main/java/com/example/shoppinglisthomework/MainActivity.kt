package com.example.shoppinglisthomework

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.shoppinglisthomework.data.Carts
import com.example.shoppinglisthomework.databinding.ActivityMainBinding
import com.google.gson.Gson
import java.io.File
import java.io.FileWriter

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Carts.restoreCartsObjectFromFile(this)






        /*
        // ##################################
        val myShoppingItem = ShopProduct(1)
        myShoppingItem.description = "MY CUSTOM DESC"
        myShoppingItem.title = "MY CUSTOM TITLE"

        myShoppingItem.edit("MY CUSTOM TITLE", "MY CUSTOM DESCRIPTION", 4, "kg")

        val myShoppingCart = ShopCart()

        myShoppingCart.addItem(ShopProduct(2)) //new empty one
        myShoppingCart.addItem(myShoppingItem) //edited one
        myShoppingCart.addItem(ShopProduct(3)) //new empty one


        printFileContent(this)
        saveShopCartToFile(this, myShoppingCart)
        */

    }



    /*
    fun saveShopCartToFile(context: Context, shopItem: ShopCart) {
        val fullPath = "data.json"
        val file = File(context.filesDir, fullPath)
        val gson = Gson()
        val toJson = gson.toJson(shopItem)
        val writer = FileWriter(file)
        writer.write(toJson)
        writer.close()
    }


    fun restoreShopCartFromFile(context: Context): ShopCart? {
        val fullPath = "data.json"
        val file = File(context.filesDir, fullPath)
        val gson = Gson()
        val objectToReturn = try {
            gson.fromJson(FileReader(file), ShopCart::class.java)
        } catch (e: java.lang.Exception) {
            Log.e("restoreShopItem", "error", e)
            null
        }
        return objectToReturn
    }

    */

    //#####################################
    /*
    fun printFileContent(context: Context) {
        val fullPath = "data.json"

        try {
            val file = File(context.filesDir, fullPath)
            val fileContent = file.readText() // read the contents of the file into a String variable
            Log.d("data.json's content: ", fileContent) // print the contents of the file to the debug console
        } catch(e: java.lang.Exception){
            Log.d("data.json's content: ", "catched an error. maybe does not exist") // print the contents of the file to the debug console
            null
        }
    }*/

}