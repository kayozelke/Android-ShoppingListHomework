package com.example.shoppinglisthomework.data

import android.os.Parcel
import android.os.Parcelable
import java.util.ArrayList

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */




object Products {

    /**
     * An array of sample (placeholder) items.
     */
    var ITEMS: MutableList<ProductItem> = ArrayList()

    var ProductListId: String = ""
    private val COUNT = 25

    init {
        // Add some sample items.
        for (i in 1..COUNT) {
            addItem(createPlaceholderItem(i))
        }
    }

    fun addItem(item: ProductItem) {
        ITEMS.add(item)
    }


    private fun createPlaceholderItem(position: Int): ProductItem {
        return ProductItem(position.toString(), "Item " + position, makeDetails(position), 0.0f, "piece(s)")
    }


    private fun makeDetails(position: Int): String {
        val builder = StringBuilder()
        builder.append("Details about Item: ").append(position)
        for (i in 0..position - 1) {
            builder.append("\nMore details information here.")
        }
        return builder.toString()
    }

    fun updateProduct(productToEdit: ProductItem?, newProduct: Products.ProductItem) {
        productToEdit?.let{ oldProduct ->
            val indexOfOldProduct = ITEMS.indexOf(oldProduct)
            ITEMS.add(indexOfOldProduct,newProduct)
            ITEMS.removeAt(indexOfOldProduct+1)
        }
    }


    /**
     * A placeholder item representing a piece of content.
     */
    data class ProductItem(val id: String, val content: String, val details: String, val quantity: Float, val unit: String) : Parcelable {
        constructor(parcel: Parcel) : this(
            parcel.readString()!!,
            parcel.readString()!!,
            parcel.readString()!!,
            parcel.readFloat()!!.toFloat(),
            parcel.readString()!!
        ) {
        }

        override fun toString(): String = "$content - ${quantity.toString()} $unit"
        override fun writeToParcel(parcel: Parcel, flags: Int) {
            parcel.writeString(id)
            parcel.writeString(content)
            parcel.writeString(details)
            parcel.writeFloat(quantity)
            parcel.writeString(unit)
        }

        override fun describeContents(): Int {
            return 0
        }

        companion object CREATOR : Parcelable.Creator<ProductItem> {
            override fun createFromParcel(parcel: Parcel): ProductItem {
                return ProductItem(parcel)
            }

            override fun newArray(size: Int): Array<ProductItem?> {
                return arrayOfNulls(size)
            }
        }

    }
}