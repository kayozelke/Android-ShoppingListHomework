package com.example.shoppinglisthomework

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.shoppinglisthomework.data.Carts
import com.example.shoppinglisthomework.data.Products
import com.example.shoppinglisthomework.databinding.CartsFragmentDisplayCartInfoBinding
import com.google.android.material.snackbar.Snackbar


/**
 * A simple [Fragment] subclass.
 * Use the [DisplayCartInfoFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DisplayCartInfoFragment : Fragment(),
    DeleteCartDialogFragment.OnDeleteCartDialogInteractionListener {
    private lateinit var binding: CartsFragmentDisplayCartInfoBinding
    val args: DisplayCartInfoFragmentArgs by navArgs()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = CartsFragmentDisplayCartInfoBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val cart = args.cart
        binding.cartTitle.text = cart.title

        val position = args.position



        binding.editCartButton.setOnClickListener {

            /*
            val productToEdit = DisplayProductFragmentDirections.actionDisplayProductFragmentToAddProductFragment(
                productToEdit = product,
                edit = true
            )
            findNavController().navigate(productToEdit)
             */

            val cartToEdit = DisplayCartInfoFragmentDirections.actionDisplayCartInfoFragmentToAddCartFragment(
                cartToEdit = cart,
                edit = true
            )
            findNavController().navigate(cartToEdit)
        }

        binding.deleteCartButton.setOnClickListener {
            showDeleteCartDialog(position)
        }
    }

    private fun showDeleteCartDialog(position: Int) {
        val deleteCartDialog = DeleteCartDialogFragment.newInstance(Carts.ITEMS.get(position).title,position,this)
        deleteCartDialog.show(requireActivity().supportFragmentManager,"DeleteDialog")
    }

    override fun onDialogPositiveClick(pos: Int?) {
        findNavController().popBackStack()
        Carts.ITEMS.removeAt(pos!!)
        Snackbar.make(requireView(), "Product deleted", Snackbar.LENGTH_LONG)
            .show()
    }

    override fun onDialogNegativeClick(pos: Int?) {
        Snackbar.make(requireView(), "Delete cancelled", Snackbar.LENGTH_LONG)
            .setAction("Redo", View.OnClickListener { showDeleteCartDialog(pos!!) })
            .show()
    }
}