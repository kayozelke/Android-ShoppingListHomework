package com.example.shoppinglisthomework

interface ProductListListener {
    fun onItemClick(positon: Int)
    fun onItemLongClick(positon: Int)
}


interface CartListListener {
    fun onCartClick(positon: Int)
    fun onCartLongClick(positon: Int)
}