package com.example.shoppinglisthomework

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.example.shoppinglisthomework.data.Carts

import com.example.shoppinglisthomework.databinding.CartsFragmentItemBinding

/**
 * [RecyclerView.Adapter] that can display a [PlaceholderItem].
 * TODO: Replace the implementation with code for your data type.
 */
class MyCartsRecyclerViewAdapter(
    private val values: MutableList<Carts.CartItem>,
    private val eventListener: CartListListener
) : RecyclerView.Adapter<MyCartsRecyclerViewAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        return ViewHolder(
            CartsFragmentItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = values[position]
        //holder.idView.text = item.id

        holder.imgView.setImageResource(R.drawable.baseline_shopping_cart_24)
        holder.contentView.text = item.title

        holder.itemContainer.setOnClickListener{
            eventListener.onCartClick(position)
        }
        holder.itemContainer.setOnLongClickListener{
            eventListener.onCartLongClick(position)
            return@setOnLongClickListener true
        }

    }

    override fun getItemCount(): Int = values.size

    inner class ViewHolder(binding: CartsFragmentItemBinding) : RecyclerView.ViewHolder(binding.root) {
        val imgView: ImageView = binding.cartImg
        val contentView: TextView = binding.cartContent
        val itemContainer: View = binding.root

        override fun toString(): String {
            return super.toString() + " '" + contentView.text + "'"
        }
    }

}