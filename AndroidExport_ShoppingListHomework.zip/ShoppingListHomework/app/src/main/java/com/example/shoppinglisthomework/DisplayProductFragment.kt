package com.example.shoppinglisthomework

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.shoppinglisthomework.data.Products
import com.example.shoppinglisthomework.databinding.ProductsFragmentDisplayProductBinding

/**
 * A simple [Fragment] subclass.
 * Use the [DisplayProductFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DisplayProductFragment : Fragment() {
    val args: DisplayProductFragmentArgs by navArgs()
    lateinit var binding : ProductsFragmentDisplayProductBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = ProductsFragmentDisplayProductBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val product: Products.ProductItem = args.product
        binding.displayTitle.text = product.content
        binding.displayDescritpion.text = product.details
        if(product.quantity != null){
            binding.displayQuantity.text = "${product.quantity} ${product.unit.toString()}"
        }
        else {
            binding.displayQuantity.text = "0.0 ${product.unit.toString()}"
        }
        binding.displayEdit.setOnClickListener {
            val productToEdit = DisplayProductFragmentDirections.actionDisplayProductFragmentToAddProductFragment(
                productToEdit = product,
                edit = true
            )
            findNavController().navigate(productToEdit)
        }
    }



}