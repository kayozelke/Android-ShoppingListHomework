package com.example.shoppinglisthomework.data

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import android.util.Log
import com.google.gson.Gson
import java.io.File
import java.io.FileReader
import java.io.FileWriter
import java.util.ArrayList

/**
 * Helper class for providing sample content for user interfaces created by
 * Android template wizards.
 *
 * TODO: Replace all uses of this class before publishing your app.
 */
object Carts {

    /**
     * An array of sample (placeholder) items.
     */

    val ITEMS: MutableList<CartItem> = ArrayList()

    private val COUNT = 3

    init {
        for (i in 1..COUNT) {

            addCart(createPlaceholderItem(i))
        }

    }


    fun saveCartsObjectToFile(context: Context) {
        val fullPath = "data.json"
        val file = File(context.filesDir, fullPath)
        val gson = Gson()
        val toJson = gson.toJson(ITEMS)
        val writer = FileWriter(file)
        writer.write(toJson)
        writer.close()
    }


    fun restoreCartsObjectFromFile(context: Context) {
        val fullPath = "data.json"
        val file = File(context.filesDir, fullPath)
        val gson = Gson()
        val restoredItemList = try {
            gson.fromJson(FileReader(file), Array<CartItem>::class.java)
        } catch (e: java.lang.Exception) {
            Log.e("restoreShopItem", "error", e)
            null
        }
        restoredItemList?.let { ITEMS.clear(); ITEMS.addAll(restoredItemList) }
    }


    //#####################################
    fun printFileContent(context: Context) {
        val fullPath = "data.json"

        try {
            val file = File(context.filesDir, fullPath)
            val fileContent = file.readText() // read the contents of the file into a String variable
            Log.d("data.json's content: ", fileContent) // print the contents of the file to the debug console
        } catch(e: java.lang.Exception){
            Log.d("data.json's content: ", "catched an error. maybe does not exist") // print the contents of the file to the debug console
            null
        }
    }




    private fun createPlaceholderItem(position: Int): CartItem {
        val PRODUCT_ITEMS: MutableList<Products.ProductItem> = ArrayList()

        return CartItem(position.toString(), "Item " + position, list = PRODUCT_ITEMS)
    }


    private fun makeDetails(position: Int): Any {
        val builder = StringBuilder()
        builder.append("Details about Item: ").append(position)
        for (i in 0..position - 1) {
            builder.append("\nMore details information here.")
        }
        return builder.toString()
    }

    fun addCart(item: CartItem) {
        ITEMS.add(item)
    }

    fun updateCart(toEditBasketArgument: CartItem?, newBasket: CartItem){
        toEditBasketArgument?.let { oldBasket ->
            val indexOfOlfBasket = ITEMS.indexOf(oldBasket)
            ITEMS.add(indexOfOlfBasket, newBasket)
            ITEMS.removeAt(indexOfOlfBasket+1)
        }
    }

    fun removeCart(toRemoveBasketArgument: CartItem?){
        toRemoveBasketArgument?.let { toRemoveBasket ->
            val indexOfOlfBasket = ITEMS.indexOf(toRemoveBasket)
            ITEMS.removeAt(indexOfOlfBasket)
        }
    }


    data class CartItem(val id: String, val title: String, var list: List<Products.ProductItem>):
        Parcelable {
        constructor(parcel: Parcel) : this(
            parcel.readString()!!,
            parcel.readString()!!,
            parcel.createTypedArrayList(Products.ProductItem)!!
        )

        override fun toString(): String = title
        override fun writeToParcel(parcel: Parcel, flags: Int) {
            parcel.writeString(id)
            parcel.writeString(title)
            parcel.writeTypedList(list)
        }

        override fun describeContents(): Int {
            return 0
        }

        companion object CREATOR : Parcelable.Creator<CartItem> {
            override fun createFromParcel(parcel: Parcel): CartItem {
                return CartItem(parcel)
            }

            override fun newArray(size: Int): Array<CartItem?> {
                return arrayOfNulls(size)
            }
        }

    }
}

