package com.example.shoppinglisthomework

import android.os.Binder
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.shoppinglisthomework.data.Carts
import com.example.shoppinglisthomework.data.Products
import com.example.shoppinglisthomework.data.Products.ITEMS
import com.example.shoppinglisthomework.data.Products.ProductListId
import com.example.shoppinglisthomework.databinding.ProductsFragmentItemBinding
import com.example.shoppinglisthomework.databinding.ProductsFragmentItemListBinding
import com.google.android.material.snackbar.Snackbar

/**
 * A fragment representing a list of Items.
 */
class ProductFragment : Fragment(), ProductListListener,
    DeleteProductDialogFragment.OnDeleteDialogInteractionListener {
    val args: ProductFragmentArgs by navArgs()
    private lateinit var binding: ProductsFragmentItemListBinding


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = ProductsFragmentItemListBinding.inflate(inflater,container,false)


        Carts.saveCartsObjectToFile(requireContext())

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        ProductListId = args.cart.id
        ITEMS = args.cart.list as MutableList<Products.ProductItem>


        with(binding.productList){
            layoutManager = LinearLayoutManager(context)
            adapter = MyProductRecyclerViewAdapter(Products.ITEMS, this@ProductFragment)
        }
        binding.addProductButton.setOnClickListener{ addProductButtonClick() }
    }




    private fun addProductButtonClick() {
        findNavController().navigate(R.id.action_productFragment_to_addProductFragment)
    }



    override fun onItemClick(positon: Int) {
        val actionTaskFragmentToDisplayProductFragmentArgs = ProductFragmentDirections.actionProductFragmentToDisplayProductFragment(Products.ITEMS.get(positon))
        findNavController().navigate(actionTaskFragmentToDisplayProductFragmentArgs)
    }

    override fun onItemLongClick(positon: Int) {
        showDeleteDialog(positon)
    }

    private fun showDeleteDialog(positon: Int) {
        val deleteDialog = DeleteProductDialogFragment.newInstance(Products.ITEMS.get(positon).content,positon,this)
        deleteDialog.show(requireActivity().supportFragmentManager,"DeleteDialog")
    }

    override fun onDialogPositiveClick(pos: Int?) {
        Products.ITEMS.removeAt(pos!!)
        Snackbar.make(requireView(), "Product deleted", Snackbar.LENGTH_LONG)
            .show()
        notifyDataSetChanged()
    }

    override fun onDialogNegativeClick(pos: Int?) {
        Snackbar.make(requireView(), "Delete cancelled", Snackbar.LENGTH_LONG)
            .setAction("Redo", View.OnClickListener { showDeleteDialog(pos!!) })
            .show()
    }
    private fun notifyDataSetChanged() {
        val rvAdapter = binding.productList.adapter
        rvAdapter?.notifyDataSetChanged()
    }

}