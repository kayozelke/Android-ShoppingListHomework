package com.example.shoppinglisthomework

import android.app.AlertDialog
import android.app.Dialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.DialogFragment

private const val PRODUCT_NAME_PARAM = "product name"
private const val PRODUCT_POS_PARAM = "product pos"

/**
 * A simple [Fragment] subclass.
 * Use the [DeleteProductDialogFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class DeleteProductDialogFragment : DialogFragment() {
    lateinit var mListener: OnDeleteDialogInteractionListener
    private var productNameParam: String? = null
    private var productPosParam: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            productNameParam = it.getString(PRODUCT_NAME_PARAM)
            productPosParam = it.getInt(PRODUCT_POS_PARAM)
        }
    }

    interface OnDeleteDialogInteractionListener{
        fun onDialogPositiveClick(pos:Int?)
        fun onDialogNegativeClick(pos:Int?)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {

        val builder: AlertDialog.Builder = AlertDialog.Builder(context)
        builder.setMessage("Delete this entry? " + "\"$productNameParam\"")
        builder.setPositiveButton("Confirm", DialogInterface.OnClickListener{ dialogInterface, i ->
            mListener?.onDialogPositiveClick(productPosParam)
        } )
        builder.setNegativeButton("Discard", DialogInterface.OnClickListener{ dialogInterface, i ->
            mListener?.onDialogNegativeClick(productPosParam)
        } )


        return builder.create()
    }


    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment DeleteProductDialogFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(name: String, pos: Int, interactionListener: OnDeleteDialogInteractionListener) =
            DeleteProductDialogFragment().apply {
                arguments = Bundle().apply {
                    putString(PRODUCT_NAME_PARAM, name)
                    putInt(PRODUCT_POS_PARAM, pos)
                }
                mListener = interactionListener
            }
    }
}
