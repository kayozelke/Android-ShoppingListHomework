package com.example.shoppinglisthomework

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.shoppinglisthomework.data.Carts
import com.example.shoppinglisthomework.data.Products
import com.example.shoppinglisthomework.databinding.CartsFragmentAddCartBinding
import java.util.ArrayList


/**
 * A simple [Fragment] subclass.
 * Use the [AddCartFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AddCartFragment : Fragment() {
private lateinit var binding: CartsFragmentAddCartBinding
val args:AddCartFragmentArgs by navArgs()
    //val args:AddCartFragmentArgs by navArgs()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = CartsFragmentAddCartBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.cartTitleInput.setText(args.cartToEdit?.title)
        binding.saveCartButton.setOnClickListener { saveCart() }
    }

    private fun saveCart() {
        var cartTitle: String = binding.cartTitleInput.text.toString()
        if(cartTitle.isEmpty()) cartTitle = getString(R.string.default_cart_title) + "${Carts.ITEMS.size + 1}"


        val newPRODUCT_ITEMS: MutableList<Products.ProductItem> = ArrayList()
        val newCartItem = Carts.CartItem(
            { cartTitle }.hashCode().toString(),
            cartTitle,
            newPRODUCT_ITEMS
        )

        if(!args.edit) {
            Carts.addCart(newCartItem)

        }else{
            Carts.updateCart(args.cartToEdit,newCartItem)
        }


        val inputMethodManager : InputMethodManager = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(binding.root.windowToken,0)
        findNavController().popBackStack(R.id.cartsFragment,false)
    }

}