package com.example.shoppinglisthomework

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import com.example.shoppinglisthomework.data.Carts
import com.example.shoppinglisthomework.databinding.CartsFragmentItemListBinding

/**
 * A fragment representing a list of Items.
 */
class CartsFragment : Fragment(), CartListListener {
    private lateinit var binding: CartsFragmentItemListBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = CartsFragmentItemListBinding.inflate(inflater,container,false)

        // Set the adapter
        with(binding.cartsList){
            layoutManager = LinearLayoutManager(context)
            adapter = MyCartsRecyclerViewAdapter(Carts.ITEMS, this@CartsFragment)
        }


        binding.addCartButton.setOnClickListener{ addCartButtonClick() }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Carts.saveCartsObjectToFile(requireContext())
        //DEBUG
        Carts.printFileContent(requireContext())

    }

    private fun addCartButtonClick() {
        findNavController().navigate(R.id.action_cartsFragment_to_addCartFragment)
    }

    override fun onCartClick(position: Int) {
        val actionListFragmentToProductFragment =
            CartsFragmentDirections.actionCartsFragmentToProductFragment(cart = Carts.ITEMS.get(position))
        Log.d("thelist: ", Carts.ITEMS.get(position).toString())
        findNavController().navigate(actionListFragmentToProductFragment)
    }

    override fun onCartLongClick(itemPosition: Int) {
        //action_cartsFragment_to_displayCartInfoFragment
        //val actionListFragmentToDisplayCartInfoFragmentArgs = CartsFragmentDirections.(Carts.ITEMS.get(positon))


        //val actionTaskFragmentToDisplayProductFragmentArgs = ProductFragmentDirections.actionProductFragmentToDisplayProductFragment(Products.ITEMS.get(positon))
        val actionListFragmentToDisplayCartInfoFragmentArgs = CartsFragmentDirections.actionCartsFragmentToDisplayCartInfoFragment(
            cart = Carts.ITEMS.get(itemPosition), position = itemPosition
        )

        findNavController().navigate(actionListFragmentToDisplayCartInfoFragmentArgs)
        //findNavController().navigate(R.id.action_cartsFragment_to_displayCartInfoFragment)
    }
}