package com.example.shoppinglisthomework

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.shoppinglisthomework.data.Products
import com.example.shoppinglisthomework.databinding.ProductsFragmentAddProductBinding


/**
 * A simple [Fragment] subclass.
 * Use the [AddProductFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class AddProductFragment : Fragment() {
    val args:AddProductFragmentArgs by navArgs()
    private lateinit var binding: ProductsFragmentAddProductBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = ProductsFragmentAddProductBinding.inflate(inflater,container,false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.saveButton.setOnClickListener { saveProduct() }
        binding.productTitleInput.setText(args.productToEdit?.content)
        binding.descriptionInput.setText(args.productToEdit?.details)

        if(args.productToEdit?.quantity == null){
            binding.productQuantityInput.setText("")
        }
        else {
            binding.productQuantityInput.setText(args.productToEdit?.quantity.toString())
        }
        val quant = resources.getStringArray(R.array.quant)
        binding.productUnitInput.setSelection(quant.indexOf(args.productToEdit?.unit))

    }

    private fun saveProduct() {
        var title: String = binding.productTitleInput.text.toString()
        var description: String = binding.descriptionInput.text.toString()

        var quantity: Float = 0.0f
        if(!binding.productQuantityInput.text.toString().isEmpty()){
            Log.d("Quantity", "\"${binding.productQuantityInput.text.toString()}\"")
            quantity = binding.productQuantityInput.text.toString().toFloat()
        }


        var unit: String = binding.productUnitInput.selectedItem.toString()
        Log.d("Unit", unit)

        if(title.isEmpty()) title = getString(R.string.default_product_title) + "${Products.ITEMS.size + 1}"
        if(description.isEmpty()) description = getString(R.string.no_description_msg)
        if(unit.isEmpty()) description = "piece(s)"
        if(quantity == null) quantity = 0.0f

        val productItem = Products.ProductItem(
            { title + description }.hashCode().toString(),
            title,
            description,
            quantity,
            unit
            )

        if(!args.edit) {
            Products.addItem(productItem)
        }else{
            Products.updateProduct(args.productToEdit,productItem)
        }

        val inputMethodManager : InputMethodManager = activity?.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(binding.root.windowToken,0)

        findNavController().popBackStack(R.id.productFragment,false)
    }

}